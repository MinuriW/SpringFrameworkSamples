package com.spring;

import java.util.ArrayList;

public class EventList {

	ArrayList<Event> eventMenu = new ArrayList<>();

	public void insert(Event event) {
		//Fill the code
	}

	public Event search(String key) {
		//Fill the code
	}

	public void supportAndAppreciation() {
		// Fill the code
	}

}
